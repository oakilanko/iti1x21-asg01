import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.Timeout;
import org.junit.rules.TestName;
import org.junit.Rule;

import java.util.Arrays;
import static org.junit.Assert.*;

import java.util.LinkedList;

public class TestTicTacToe {

    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // 1 seconds max per method tested

    @Rule
    public TestName testName = new TestName();

    @Before
    public void printTestMethod() {
      System.out.println("\t" + testName.getMethodName());
    }

    @Test
    public void testValueAtInitializeToEmpty() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      assertEquals(CellValue.EMPTY, game.valueAt(1));
      assertEquals(CellValue.EMPTY, game.valueAt(2));
      assertEquals(CellValue.EMPTY, game.valueAt(3));
      assertEquals(CellValue.EMPTY, game.valueAt(4));
      assertEquals(CellValue.EMPTY, game.valueAt(5));
      assertEquals(CellValue.EMPTY, game.valueAt(6));
    }

    @Test
    public void testValueAtInvalidIndex() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      assertEquals(CellValue.INVALID, game.valueAt(0));
      assertEquals(CellValue.INVALID, game.valueAt(7));
    }

    @Test
    public void testValueAtPlayed() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      game.play(1);
      assertEquals(CellValue.X, game.valueAt(1));

      game.play(2);
      assertEquals(CellValue.O, game.valueAt(2));

      game.play(3);
      assertEquals(CellValue.X, game.valueAt(3));
    }

    @Test
    public void testValueAtPlayedInvalidPlace() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      game.play(0);
      assertEquals(CellValue.INVALID, game.valueAt(0));
    }

    @Test
    public void testValueAtRowColumnOk() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      game.play(1);
      game.play(2);
      game.play(3);
      game.play(4);
      game.play(5);

      assertEquals(CellValue.X, game.valueAt(1,1));
      assertEquals(CellValue.O, game.valueAt(1,2));
      assertEquals(CellValue.X, game.valueAt(1,3));
      assertEquals(CellValue.O, game.valueAt(2,1));
      assertEquals(CellValue.X, game.valueAt(2,2));
      assertEquals(CellValue.EMPTY, game.valueAt(2,3));
    }

    @Test
    public void testValueAtRowColumnInvalid() {
      TicTacToe game = new TicTacToe(2, 3, 2);

      assertEquals(CellValue.INVALID, game.valueAt(0,0));
      assertEquals(CellValue.INVALID, game.valueAt(0,1));
      assertEquals(CellValue.INVALID, game.valueAt(1,0));

      assertEquals(CellValue.INVALID, game.valueAt(3,3));
      assertEquals(CellValue.INVALID, game.valueAt(2,4));
      assertEquals(CellValue.INVALID, game.valueAt(3,4));
    }

    @Test
    public void testToStringDefaultGame() {
      TicTacToe game = new TicTacToe();

      String expected = "" +
        "   |   |   \n" +
        "-----------\n" +
        "   |   |   \n" +
        "-----------\n" +
        "   |   |   ";

      assertEquals(expected, game.toString());
    }

    @Test
    public void testToStringSmallGame() {
      TicTacToe game = new TicTacToe(2, 2, 2);

      String expected = "" +
        "   |   \n" +
        "-------\n" +
        "   |   ";

      assertEquals(expected, game.toString());
    }

    @Test
    public void testToStringBigGame() {
      TicTacToe game = new TicTacToe(5, 5, 2);

      String expected = "" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   ";

      assertEquals(expected, game.toString());
    }

    @Test
    public void testToStringUnevenGame() {
      TicTacToe game = new TicTacToe(3, 5, 2);

      String expected = "" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   \n" +
        "-------------------\n" +
        "   |   |   |   |   ";

      assertEquals(expected, game.toString());
    }

    @Test
    public void testToStringBoardPieces() {
      TicTacToe game = new TicTacToe(3, 5, 3);

      game.play(1);
      game.play(2);
      game.play(3);
      game.play(4);
      game.play(5);
      game.play(6);
      game.play(11);
      game.play(15);

      String expected = "" +
        " X | O | X | O | X \n" +
        "-------------------\n" +
        " O |   |   |   |   \n" +
        "-------------------\n" +
        " X |   |   |   | O ";

      assertEquals(expected, game.toString());
    }

    @Test
    public void testCurrentNextPlayerSwitches() {
      TicTacToe game = new TicTacToe();

      assertEquals(CellValue.EMPTY, game.currentPlayer);
      assertEquals(CellValue.X, game.nextPlayer());

      game.play(1);
      assertEquals(CellValue.X, game.currentPlayer);
      assertEquals(CellValue.O, game.nextPlayer());

      game.play(2);
      assertEquals(CellValue.O, game.currentPlayer);
      assertEquals(CellValue.X, game.nextPlayer());

      game.play(3);
      assertEquals(CellValue.X, game.currentPlayer);
      assertEquals(CellValue.O, game.nextPlayer());
    }

    @Test
    public void testPlayRecordsMove() {
      TicTacToe game = new TicTacToe();

      assertEquals(CellValue.EMPTY, game.valueAt(1));
      assertEquals(CellValue.EMPTY, game.valueAt(2));
      assertEquals(CellValue.EMPTY, game.valueAt(3));

      game.play(1);
      assertEquals(CellValue.X, game.valueAt(1));

      game.play(2);
      assertEquals(CellValue.O, game.valueAt(2));

      game.play(3);
      assertEquals(CellValue.X, game.valueAt(3));
    }

    @Test
    public void testShowMessages() {
      TicTacToe game = new TicTacToe();

      String[] messages;

      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[0], game.toString());
      assertEquals(messages[1], "X to play: ");

      game.play(1);

      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[0], game.toString());
      assertEquals(messages[1], "O to play: ");

      game.play(2);

      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[0], game.toString());
      assertEquals(messages[1], "X to play: ");
    }

    @Test
    public void testShowAfterInvalidPosition() {
      TicTacToe game = new TicTacToe();

      String[] messages;

      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "X to play: ");

      game.play(0);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "X to play: ");

      game.play(1);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "O to play: ");

      game.play(10);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "O to play: ");
    }

    @Test
    public void testShowAfterPositionAlreadyTaken() {
      TicTacToe game = new TicTacToe();

      String[] messages;

      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "X to play: ");

      game.play(1);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "O to play: ");

      game.play(1);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "O to play: ");

      game.play(2);
      messages = game.show();
      assertEquals(2, messages.length);
      assertEquals(messages[1], "X to play: ");
    }

    @Test
    public void testPlayNoMessage() {
      TicTacToe game = new TicTacToe();
      String message = game.play(1);
      assertEquals(null, message);
    }

    @Test
    public void testPlayInvalidPositionMessage() {
      TicTacToe game;
      String message;

      game = new TicTacToe(2, 3, 2);
      message = game.play(1);
      assertEquals(null, message);

      message = game.play(0);
      assertEquals("The value should be between 1 and 6", message);

      game = new TicTacToe(4, 3, 2);
      message = game.play(13);
      assertEquals("The value should be between 1 and 12", message);
    }

    @Test
    public void testPlaySpotTakenMessage() {
      TicTacToe game = new TicTacToe(2, 3, 2);
      String message;

      game.play(1);
      game.play(2);

      message = game.play(1);
      assertEquals("Cell 1 has already been played with X", message);

      message = game.play(2);
      assertEquals("Cell 2 has already been played with O", message);
    }

    @Test
    public void testPlayFindWinnerRow() {
      TicTacToe game = new TicTacToe(2, 3, 2);
      String message;

      message = game.play(1);
      assertEquals(null, message);

      game.play(3);
      assertEquals(null, message);

      message = game.play(2);
      assertEquals("Result: XWIN", message);
    }

    @Test
    public void testPlayFindWinnerColumn() {
      TicTacToe game = new TicTacToe(5, 5, 4);
      String message;

      game.play(1);
      game.play(2);

      game.play(3);
      game.play(7);

      game.play(5);
      game.play(17);

      game.play(4);

      message = game.play(12);
      assertEquals("Result: OWIN", message);
    }

    @Test
    public void testPlayFindWinnerDiagonalLeftToRight() {
      TicTacToe game = new TicTacToe(5, 5, 4);
      String message;

      game.play(1);
      game.play(2);

      game.play(7);
      game.play(8);

      game.play(19);
      game.play(9);

      message = game.play(13);
      assertEquals("Result: XWIN", message);
    }

    @Test
    public void testPlayFindWinnerDiagonalRightToLeft() {
      TicTacToe game = new TicTacToe(4, 4, 4);
      String message;

      game.play(2);
      game.play(4);

      game.play(8);
      game.play(7);

      game.play(9);
      game.play(13);

      game.play(11);

      message = game.play(10);
      assertEquals("Result: OWIN", message);
    }

    @Test
    public void testPlayFindWinnerCorner() {
      TicTacToe game = new TicTacToe(3, 3, 3);
      String message;

      game.play(1);
      game.play(2);
      game.play(3);
      game.play(4);
      game.play(5);
      game.play(6);

      message = game.play(7);
      assertEquals("Result: XWIN", message);
    }

    @Test
    public void testPlayToADraw() {
      TicTacToe game = new TicTacToe(2, 3, 3);
      String message;

      game.play(1);
      game.play(2);
      game.play(3);
      game.play(4);
      game.play(5);
      message = game.play(6);

      assertEquals("Result: DRAW", message);
    }

    @Test
    public void testPlayAlreadyWon() {
      TicTacToe game = new TicTacToe(2, 4, 3);
      String message;

      game.play(1);
      game.play(5);

      game.play(3);
      game.play(6);

      message = game.play(2);
      assertEquals("Result: XWIN", message);

      message = game.play(7);
      assertEquals(null, message);
    }

    public static void main(String[] args) {
        TestUtils.runClass(TestTicTacToe.class);
    }

}
